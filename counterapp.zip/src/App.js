import React from "react";
import { CounterPage } from "./page/CounterPages";

const App=()=>{
 
  return(
    <CounterPage/>
  )
}
export default App;